<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TimeEntryController extends Controller
{
    public function start(\Illuminate\Http\Request $request, \App\Models\Task $task)
    {
        // Stop any currently running timer for this user
        $activeEntry = \App\Models\TimeEntry::where('user_id', auth()->id())
            ->whereNull('end_time')
            ->first();

        if ($activeEntry) {
            $now = now();
            $activeEntry->update([
                'end_time' => $now,
                'duration' => $activeEntry->start_time->diffInSeconds($now, true),
            ]);
        }

        \App\Models\TimeEntry::create([
            'user_id' => auth()->id(),
            'project_id' => $task->project_id,
            'task_id' => $task->id,
            'start_time' => now(),
            'description' => 'Working on: ' . $task->title,
        ]);

        $task->update(['status' => 'in_progress']);

        return back()->with('success', 'Timer started for task: ' . $task->title);
    }

    public function stop()
    {
        $activeEntry = \App\Models\TimeEntry::where('user_id', auth()->id())
            ->whereNull('end_time')
            ->latest()
            ->first();

        if ($activeEntry) {
            $now = now();
            $activeEntry->update([
                'end_time' => $now,
                'duration' => $activeEntry->start_time->diffInSeconds($now, true),
            ]);
            return back()->with('success', 'Timer stopped.');
        }

        return back()->with('warning', 'No active timer found.');
    }

    public function index()
    {
        $entries = \App\Models\TimeEntry::with(['project', 'task'])->where('user_id', auth()->id())->latest()->paginate(25);
        return view('time-entries.index', compact('entries'));
    }
}
