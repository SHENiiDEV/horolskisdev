<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice #<?php echo e(str_pad($invoice->id, 5, '0', STR_PAD_LEFT)); ?> - HOROLSKIS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .page-break {
                page-break-inside: avoid;
            }
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen p-8 text-gray-900 font-sans antialiased">

    <!-- Actions Bar -->
    <div class="max-w-[210mm] mx-auto mb-6 flex justify-between items-center no-print">
        <a href="<?php echo e(route('dashboard')); ?>"
            class="flex items-center text-sm font-medium text-gray-500 hover:text-gray-900 transition-colors">
            <svg class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Dashboard
        </a>
        <button onclick="window.print()"
            class="inline-flex items-center px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg shadow-sm hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-colors">
            <svg class="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Print / Save PDF
        </button>
    </div>

    <!-- Invoice Container (A4 Proportions approx) -->
    <div
        class="max-w-[210mm] mx-auto bg-white shadow-2xl rounded-xl overflow-hidden print:shadow-none print:rounded-none">

        <!-- Top accent -->
        <div class="h-2 bg-gradient-to-r from-gray-900 to-gray-700"></div>

        <div class="p-12">
            <!-- Header -->
            <div class="flex justify-between items-start mb-16">
                <div>
                    <!-- Brand -->
                    <h1 class="text-4xl font-black tracking-tight text-gray-900">HOROLSKIS</h1>
                    <p class="text-sm text-gray-500 mt-1 uppercase tracking-widest font-medium">Developer</p>
                </div>
                <div class="text-right">
                    <h2 class="text-base font-semibold text-gray-400 uppercase tracking-widest mb-2">Invoice</h2>
                    <p class="text-4xl font-light text-gray-900">
                        #<?php echo e($invoice->public_id ?? str_pad($invoice->id, 5, '0', STR_PAD_LEFT)); ?></p>
                    <div class="mt-4 flex justify-end">
                        <form action="<?php echo e(route('invoices.update', $invoice->id)); ?>" method="POST" class="no-print">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="status" onchange="this.form.submit()"
                                class="appearance-none cursor-pointer inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide border-0 focus:ring-2 focus:ring-indigo-500 <?php echo e($invoice->status === 'paid' ? 'bg-green-100 text-green-700' : ($invoice->status === 'sent' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-600')); ?>">
                                <option value="draft" <?php echo e($invoice->status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                                <option value="sent" <?php echo e($invoice->status === 'sent' ? 'selected' : ''); ?>>Sent</option>
                                <option value="paid" <?php echo e($invoice->status === 'paid' ? 'selected' : ''); ?>>Paid</option>
                            </select>
                        </form>
                        <div
                            class="hidden print:inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide <?php echo e($invoice->status === 'paid' ? 'bg-green-100 text-green-700' : ($invoice->status === 'sent' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-600')); ?>">
                            <?php echo e(ucfirst($invoice->status)); ?>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Addresses & Meta -->
            <div class="grid grid-cols-2 gap-12 mb-16 border-b border-gray-100 pb-12">
                <div class="space-y-10">
                    <div>
                        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Paid To</h3>
                        <p class="font-bold text-gray-900 text-lg">Mihails Horolskis</p>
                        <div class="text-gray-500 text-sm mt-2 leading-relaxed">
                            Riga, Latvia<br>
                            info@horolskis.lv
                        </div>
                    </div>

                    <div class="grid grid-cols-5 gap-4">
                        <div class="col-span-2">
                            <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Issue Date</h3>
                            <p class="font-medium text-sm text-gray-900"><?php echo e($invoice->created_at->format('M d, Y')); ?>

                            </p>
                        </div>
                        <div class="col-span-3">
                            <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Billing Period
                            </h3>
                            <p class="font-medium text-sm text-gray-900 whitespace-nowrap">
                                <?php echo e(\Carbon\Carbon::parse($invoice->period_start)->format('M d')); ?> —
                                <?php echo e(\Carbon\Carbon::parse($invoice->period_end)->format('M d, Y')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div>
                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Billed To</h3>
                    <p class="font-bold text-gray-900 text-lg"><?php echo e($invoice->client->name); ?></p>
                    <div class="text-gray-500 text-sm mt-2 leading-relaxed">
                        <?php if($invoice->client->address): ?>
                            <p><?php echo e($invoice->client->address); ?></p>
                            <p><?php echo e($invoice->client->city); ?>, <?php echo e($invoice->client->postal_code); ?></p>
                            <p><?php echo e($invoice->client->country); ?></p>
                        <?php endif; ?>
                        <?php if($invoice->client->vat_number): ?>
                            <p class="mt-2">VAT: <?php echo e($invoice->client->vat_number); ?></p>
                        <?php endif; ?>
                        <?php if($invoice->client->registration_number): ?>
                            <p>Reg: <?php echo e($invoice->client->registration_number); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Area -->
        <div class="mb-12">
            <h3 class="text-xl font-bold text-gray-900 mb-6">Services Breakdown</h3>

            <?php if($invoice->notes): ?>
                <div class="bg-gray-50 rounded-lg p-4 mb-8 text-sm text-gray-600 leading-relaxed border border-gray-100">
                    <?php echo e($invoice->notes); ?>

                </div>
            <?php endif; ?>

            <div class="overflow-hidden rounded-lg border border-gray-200">
                <table class="w-full text-sm text-left">
                    <thead class="bg-gray-50/50 text-gray-500 font-medium">
                        <tr>
                            <th class="px-6 py-4 w-[45%]">Description</th>
                            <th class="px-4 py-4 text-right whitespace-nowrap">Hours / Qty</th>
                            <th class="px-4 py-4 text-right whitespace-nowrap">Rate</th>
                            <th class="px-6 py-4 text-right whitespace-nowrap">Amount</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $invoice->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalSeconds = $task->timeEntries->sum('duration');
                                $hours = $totalSeconds / 3600;
                                if ($task->pricing_type === 'fixed') {
                                    $cost = $task->rate ?? 0;
                                } else {
                                    $rate = $task->rate ?? 0;
                                    $cost = $rate * $hours;
                                }
                            ?>
                            <tr class="bg-white page-break">
                                <td class="px-6 py-4 align-top">
                                    <p class="font-semibold text-gray-900"><?php echo e($task->title); ?></p>
                                    <?php if($task->description): ?>
                                        <p class="text-gray-500 text-xs mt-1 leading-relaxed">
                                            <?php echo e(Str::limit($task->description, 100)); ?>

                                        </p>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-4 text-right align-top text-gray-600 tabular-nums whitespace-nowrap">
                                    <?php if($task->pricing_type !== 'fixed'): ?>
                                        <?php echo e(number_format($hours, 2)); ?>

                                    <?php else: ?>
                                        <span class="text-gray-400">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-4 text-right align-top text-gray-600 tabular-nums whitespace-nowrap">
                                    <?php if($task->pricing_type !== 'fixed'): ?>
                                        € <?php echo e(number_format($task->rate, 2)); ?>

                                    <?php else: ?>
                                        <span
                                            class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100/10 text-gray-600">Fixed</span>
                                    <?php endif; ?>
                                </td>
                                <td
                                    class="px-6 py-4 text-right align-top font-semibold text-gray-900 tabular-nums whitespace-nowrap">
                                    € <?php echo e(number_format($cost, 2)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($invoice->items): ?>
                            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white page-break">
                                    <td class="px-6 py-4 align-top">
                                        <p class="font-semibold text-gray-900"><?php echo e($item['description']); ?></p>
                                    </td>
                                    <td class="px-4 py-4 text-right align-top text-gray-600 tabular-nums whitespace-nowrap">
                                        <?php echo e(number_format((float) $item['quantity'], 2)); ?>

                                    </td>
                                    <td class="px-4 py-4 text-right align-top text-gray-600 tabular-nums whitespace-nowrap">
                                        € <?php echo e(number_format((float) $item['rate'], 2)); ?>

                                    </td>
                                    <td
                                        class="px-6 py-4 text-right align-top font-semibold text-gray-900 tabular-nums whitespace-nowrap">
                                        € <?php echo e(number_format((float) $item['amount'], 2)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="bg-gray-50">
                        <tr>
                            <td colspan="3"
                                class="px-6 py-6 text-right font-medium text-gray-500 uppercase tracking-widest text-xs">
                                Total Amount</td>
                            <td class="px-6 py-6 text-right text-2xl font-black text-gray-900 tabular-nums">
                                €<?php echo e(number_format($invoice->amount, 2)); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Footer -->
        <div class="mt-20 pt-8 border-t border-gray-100 flex flex-col items-center text-center">
            <div class="flex items-center justify-center space-x-3 mb-4">
                <img src="<?php echo e(asset('img/swedbank-logo.png')); ?>" alt="Swedbank Logo" class="h-12 w-auto object-contain">
                <span class="text-xl font-bold text-orange-500 tracking-tight">Swedbank</span>
            </div>

            <div class="bg-gray-50 rounded-xl px-10 py-6 border border-gray-200 shadow-sm w-full max-w-lg">
                <div class="space-y-3">
                    <div>
                        <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold">Receiver</p>
                        <p class="text-gray-900 font-bold text-lg">MIHAILS HOROĻSKIS</p>
                    </div>

                    <div>
                        <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold">IBAN</p>
                        <p class="font-mono text-lg text-gray-800 tracking-wide font-medium select-all">LV04 HABA
                            0551 0592 0525 3</p>
                    </div>

                    <div class="pt-2 border-t border-gray-200 mt-2">
                        <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold text-center mb-1">
                            Payment Details / Mērķis</p>
                        <p
                            class="text-gray-900 font-medium bg-white px-3 py-1 rounded border border-gray-200 inline-block text-sm">
                            Apmaksajums rekinu:
                            <?php echo e($invoice->public_id ?? str_pad($invoice->id, 5, '0', STR_PAD_LEFT)); ?>

                        </p>
                    </div>
                </div>
            </div>

            <p class="mt-6 text-xs text-gray-400">Payment is due within 14 days of the invoice date.</p>
        </div>

    </div>
    </div>
</body>

</html><?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/invoices/show.blade.php ENDPATH**/ ?>