<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Global Kanban Board')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="h-[calc(100vh-12rem)] overflow-x-auto overflow-y-hidden" x-data="{
        updateTaskStatus(taskId, status) {
            fetch(`/tasks/${taskId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ status: status })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Task updated:', data);
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to update task status');
            });
        }
    }">
        <div class="flex h-full gap-6 pb-4 min-w-[1024px]">
            <?php $__currentLoopData = ['pending' => 'Pending', 'in_progress' => 'In Progress', 'done' => 'Done', 'paid' => 'Paid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex-1 flex flex-col bg-gray-50 rounded-lg border border-gray-200 h-full" 
                    <?php if($statusKey !== 'paid'): ?>
                    x-on:dragover.prevent
                    x-on:drop="
                            let taskId = $event.dataTransfer.getData('text/plain');
                            let card = document.getElementById('task-' + taskId);
                            if(card) {
                                $el.querySelector('.task-container').appendChild(card);
                                updateTaskStatus(taskId, '<?php echo e($statusKey); ?>');
                            }
                         "
                    <?php endif; ?>
                    >
                    <!-- Column Header -->
                    <div class="p-3 border-b border-gray-200 bg-gray-100/50 flex justify-between items-center rounded-t-lg">
                        <h3 class="font-semibold text-sm text-gray-700 uppercase tracking-wider flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full 
                                    <?php echo e($statusKey === 'pending' ? 'bg-yellow-400' : ''); ?>

                                    <?php echo e($statusKey === 'in_progress' ? 'bg-blue-500' : ''); ?>

                                    <?php echo e($statusKey === 'done' ? 'bg-green-500' : ''); ?>

                                    <?php echo e($statusKey === 'paid' ? 'bg-purple-500' : ''); ?>

                                "></span>
                            <?php echo e($statusLabel); ?>

                        </h3>
                        <span class="bg-gray-200 text-gray-600 py-0.5 px-2 rounded-full text-xs font-medium">
                            <?php if($statusKey === 'paid'): ?>
                                <?php echo e($tasks->filter(fn($t) => $t->invoice && $t->invoice->status === 'paid')->count()); ?>

                            <?php elseif($statusKey === 'done'): ?>
                                <?php echo e($tasks->filter(fn($t) => $t->status === 'done' && (!$t->invoice || $t->invoice->status !== 'paid'))->count()); ?>

                            <?php else: ?>
                                <?php echo e($tasks->where('status', $statusKey)->count()); ?>

                            <?php endif; ?>
                        </span>
                    </div>

                    <!-- Tasks Container -->
                    <div class="task-container flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
                        <?php
                            $filteredTasks = collect();
                            if ($statusKey === 'paid') {
                                $filteredTasks = $tasks->filter(fn($t) => $t->invoice && $t->invoice->status === 'paid');
                            } elseif ($statusKey === 'done') {
                                $filteredTasks = $tasks->filter(fn($t) => $t->status === 'done' && (!$t->invoice || $t->invoice->status !== 'paid'));
                            } else {
                                $filteredTasks = $tasks->where('status', $statusKey);
                            }
                        ?>

                        <?php $__currentLoopData = $filteredTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="task-<?php echo e($task->id); ?>" 
                                <?php if($statusKey !== 'paid'): ?> draggable="true" class="cursor-move group"
                                x-on:dragstart="$event.dataTransfer.setData('text/plain', '<?php echo e($task->id); ?>'); $event.dataTransfer.effectAllowed = 'move';"
                                <?php else: ?> class="opacity-75" <?php endif; ?>
                                >
                                <?php echo $__env->make('projects.partials.task-card', ['task' => $task, 'showProject' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/tasks/kanban.blade.php ENDPATH**/ ?>