<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e($client->name); ?>

            </h2>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('clients.edit', $client)); ?>"
                    class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 transition">
                    Edit Client
                </a>
                
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Client Details -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900">Contact & Company Info</h3>
                    <div class="mt-2 text-gray-600 space-y-1">
                        <?php if($client->email): ?>
                        <p><strong>Email:</strong> <?php echo e($client->email); ?></p> <?php endif; ?>
                        <?php if($client->phone): ?>
                        <p><strong>Phone:</strong> <?php echo e($client->phone); ?></p> <?php endif; ?>
                        <?php if($client->vat_number): ?>
                        <p><strong>VAT:</strong> <?php echo e($client->vat_number); ?></p> <?php endif; ?>
                        <?php if($client->registration_number): ?>
                        <p><strong>Reg No:</strong> <?php echo e($client->registration_number); ?></p> <?php endif; ?>
                    </div>

                    <h3 class="mt-4 text-lg font-medium text-gray-900">Address</h3>
                    <div class="mt-2 text-gray-600">
                        <p><?php echo e($client->address); ?></p>
                        <p><?php echo e($client->city); ?>, <?php echo e($client->postal_code); ?></p>
                        <p><?php echo e($client->country); ?></p>
                    </div>

                    <?php if($client->notes): ?>
                        <h3 class="mt-4 text-lg font-medium text-gray-900">Notes</h3>
                        <p class="mt-1 text-gray-600 whitespace-pre-line"><?php echo e($client->notes); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Projects Grid -->
            <div class="flex justify-between items-center mt-8">
                <h3 class="text-xl font-bold text-gray-800">Projects</h3>
                <a href="<?php echo e(route('projects.create', ['client_id' => $client->id])); ?>"
                    class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 transition">
                    Add Project
                </a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__empty_1 = true; $__currentLoopData = $client->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg hover:shadow-md transition">
                        <div class="p-6">
                            <div class="flex justify-between items-start">
                                <h4 class="text-lg font-bold text-indigo-700">
                                    <a href="<?php echo e(route('projects.show', $project)); ?>"><?php echo e($project->name); ?></a>
                                </h4>
                                <span
                                    class="px-2 py-1 text-xs rounded-full <?php echo e($project->status === 'live' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                    <?php echo e(ucfirst($project->status)); ?>

                                </span>
                            </div>
                            <p class="mt-2 text-sm text-gray-500"><?php echo e($project->domain ?? 'No domain'); ?></p>

                            <hr class="my-4">

                            <div class="flex justify-between text-sm text-gray-600">
                                <span><?php echo e($project->tasks_count ?? 0); ?> Tasks</span>
                                <span><?php echo e($project->pricing_type); ?></span>
                            </div>

                            <div class="mt-4 text-right">
                                <a href="#" class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">Manage
                                    &rarr;</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div
                        class="col-span-full text-center py-10 bg-gray-50 rounded-lg dashed border-2 border-gray-300 text-gray-500">
                        No projects found for this client.
                    </div>
                <?php endif; ?>
            </div>

            <!-- Invoices Section -->
            <div class="flex justify-between items-center mt-12">
                <h3 class="text-xl font-bold text-gray-800">Invoices</h3>
                <a href="<?php echo e(route('invoices.create', ['client_id' => $client->id])); ?>"
                    class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 transition">
                    Create Invoice
                </a>
            </div>

            <div class="mt-6 bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <ul class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $client->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="p-6 hover:bg-gray-50 flex justify-between items-center">
                            <div>
                                <h4 class="text-lg font-bold text-gray-900">
                                    <a
                                        href="<?php echo e(route('invoices.show', $invoice)); ?>">#<?php echo e(str_pad($invoice->id, 5, '0', STR_PAD_LEFT)); ?></a>
                                </h4>
                                <p class="text-sm text-gray-500"><?php echo e($invoice->created_at->format('M d, Y')); ?> —
                                    €<?php echo e(number_format($invoice->total_amount, 2)); ?></p>
                            </div>
                            <span
                                class="px-2 py-1 text-xs rounded-full <?php echo e($invoice->status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                                <?php echo e(ucfirst($invoice->status)); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="p-6 text-center text-gray-500">No invoices found.</li>
                    <?php endif; ?>
                </ul>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/clients/show.blade.php ENDPATH**/ ?>