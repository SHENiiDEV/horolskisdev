<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Invoice <?php echo e($invoice->public_id); ?></title>
    <style>
        @page {
            margin: 0cm 0cm;
        }

        body {
            font-family: 'DejaVu Sans', sans-serif;
            margin-top: 2cm;
            margin-left: 2cm;
            margin-right: 2cm;
            margin-bottom: 2cm;
            color: #111827;
            background: #fff;
            line-height: 1.5;
            font-size: 12px;
        }

        .header {
            margin-bottom: 50px;
            width: 100%;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #4f46e5;
            float: left;
        }

        .status {
            float: right;
            text-transform: uppercase;
            font-weight: bold;
            font-size: 10px;
            padding: 4px 8px;
            border-radius: 4px;
        }

        .status.paid {
            background-color: #dcfce7;
            color: #15803d;
        }

        .status.sent {
            background-color: #dbeafe;
            color: #1e40af;
        }

        .status.draft {
            background-color: #f3f4f6;
            color: #374151;
        }

        .clearfix:after {
            content: "";
            display: table;
            clear: both;
        }

        .client-info {
            margin-bottom: 50px;
        }

        .billing-to {
            float: left;
            width: 55%;
        }

        .invoice-details {
            float: right;
            width: 40%;
            text-align: right;
        }

        .invoice-details p {
            margin: 2px 0;
            color: #6b7280;
            font-size: 11px;
        }

        .invoice-details strong {
            display: block;
            color: #111827;
            font-size: 13px;
            margin-bottom: 10px;
        }

        /* Sender Details (Top Left helper or just context) */
        .sender-details {
            margin-top: 5px;
            font-size: 10px;
            color: #6b7280;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th {
            text-align: left;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
            color: #6b7280;
            font-weight: 600;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }

        td {
            padding: 15px 0;
            border-bottom: 1px solid #f9fafb;
            vertical-align: top;
        }

        .text-right {
            text-align: right;
        }

        .font-medium {
            font-weight: bold;
        }

        .text-gray-500 {
            color: #6b7280;
        }

        .totals {
            width: 40%;
            float: right;
            border-top: 1px solid #e5e7eb;
            padding-top: 15px;
        }

        .total-row {
            margin-bottom: 8px;
            font-size: 12px;
        }

        .total-row.final {
            font-size: 18px;
            font-weight: bold;
            color: #111827;
            margin-top: 15px;
        }

        .total-label {
            float: left;
            color: #6b7280;
        }

        .total-value {
            float: right;
        }

        /* Swedbank Block */
        .payment-block {
            margin-top: 60px;
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            font-family: 'DejaVu Sans', sans-serif;
            page-break-inside: avoid;
        }

        .swedbank-logo {
            text-align: center;
            margin-bottom: 15px;
            color: #f97316;
            /* orange-500 */
            font-weight: bold;
            font-size: 16px;
        }

        .payment-detail {
            text-align: center;
            margin-bottom: 10px;
        }

        .payment-label {
            font-size: 10px;
            text-transform: uppercase;
            color: #6b7280;
            letter-spacing: 1px;
            margin-bottom: 2px;
        }

        .payment-value {
            font-size: 14px;
            font-weight: bold;
            color: #111827;
        }

        .payment-iban {
            font-family: monospace;
            font-size: 16px;
            letter-spacing: 2px;
        }

        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #f3f4f6;
            color: #9ca3af;
            font-size: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Header -->
        <div class="header clearfix">
            <div class="logo">
                HOROLSKIS DEVELOPER
                <div class="sender-details">
                    Mihails Horoļskis<br>
                    Reg. No: 221194-10523<br>
                    Lepju iela 9, Riga, Latvia
                </div>
            </div>
            <div class="status <?php echo e($invoice->status); ?>">
                <?php echo e(strtoupper($invoice->status)); ?>

            </div>
        </div>

        <!-- Client & Invoice Info -->
        <div class="client-info clearfix">
            <div class="billing-to">
                <p
                    style="color: #6b7280; font-size: 10px; font-weight: 600; text-transform: uppercase; margin-bottom: 10px;">
                    Billed To</p>
                <h3 style="margin: 0; font-size: 16px; margin-bottom: 5px; font-weight: bold">
                    <?php echo e($invoice->client->name); ?>

                </h3>

                <div style="color: #4b5563; font-size: 12px; line-height: 1.6;">
                    <?php if($invoice->client->address): ?>
                        <?php echo e($invoice->client->address); ?><br>
                    <?php endif; ?>
                    <?php if($invoice->client->city || $invoice->client->postal_code): ?>
                        <?php echo e($invoice->client->city); ?> <?php echo e($invoice->client->postal_code); ?><br>
                    <?php endif; ?>
                    <?php if($invoice->client->country): ?>
                        <?php echo e($invoice->client->country); ?><br>
                    <?php endif; ?>

                    <?php if($invoice->client->vat_number): ?>
                        <br><strong>VAT:</strong> <?php echo e($invoice->client->vat_number); ?>

                    <?php endif; ?>
                    <?php if($invoice->client->registration_number): ?>
                        <br><strong>REG:</strong> <?php echo e($invoice->client->registration_number); ?>

                    <?php endif; ?>
                </div>
            </div>

            <div class="invoice-details">
                <p>Invoice Number</p>
                <strong><?php echo e($invoice->public_id); ?></strong>

                <p>Date Issued</p>
                <strong><?php echo e($invoice->period_start->format('Y-m-d')); ?></strong>

                <p>Due Date</p>
                <strong><?php echo e($invoice->period_end->format('Y-m-d')); ?></strong>
            </div>
        </div>

        <!-- Items Table -->
        <table>
            <thead>
                <tr>
                    <th style="width: 50%;">Description</th>
                    <th class="text-right">Qty / Hrs</th>
                    <th class="text-right">Rate</th>
                    <th class="text-right">Amount</th>
                </tr>
            </thead>
            <tbody>
                <!-- Tasks -->
                <?php $__currentLoopData = $invoice->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $totalSeconds = $task->timeEntries->sum('duration');
                        $hours = $totalSeconds / 3600;
                        if ($task->pricing_type === 'fixed') {
                            $cost = $task->rate ?? 0;
                        } else {
                            $rate = $task->rate ?? 0;
                            $cost = $rate * $hours;
                        }
                    ?>
                    <tr>
                        <td>
                            <div class="font-medium"><?php echo e($task->title); ?></div>
                        </td>
                        <td class="text-right">
                            <?php if($task->pricing_type !== 'fixed'): ?>
                                <?php echo e(number_format($hours, 2)); ?>

                            <?php else: ?>
                                1
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            € <?php echo e(number_format($task->rate, 2)); ?>

                        </td>
                        <td class="text-right font-medium">
                            € <?php echo e(number_format($cost, 2)); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Custom Items -->
                <?php if($invoice->items): ?>
                    <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="font-medium"><?php echo e($item['description']); ?></div>
                            </td>
                            <td class="text-right"><?php echo e($item['quantity']); ?></td>
                            <td class="text-right">€ <?php echo e(number_format($item['rate'], 2)); ?></td>
                            <td class="text-right font-medium">€ <?php echo e(number_format($item['amount'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Totals -->
        <div class="clearfix">
            <div class="totals">
                <div class="total-row clearfix">
                    <span class="total-label">Subtotal</span>
                    <span class="total-value">€ <?php echo e(number_format($invoice->amount, 2)); ?></span>
                </div>
                <!-- Tax could go here if added later -->
                <div class="total-row final clearfix">
                    <span class="total-label" style="color: #111827;">Total Due</span>
                    <span class="total-value">€ <?php echo e(number_format($invoice->amount, 2)); ?></span>
                </div>
            </div>
        </div>

        <!-- Notes -->
        <?php if($invoice->notes): ?>
            <div style="margin-top: 30px; border-top: 1px solid #f3f4f6; padding-top: 15px;">
                <p style="font-weight: bold; font-size: 11px; margin-bottom: 5px;">Notes</p>
                <p style="color: #6b7280;"><?php echo nl2br(e($invoice->notes)); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Payment Block (Bottom Page) -->
    <div style="position: absolute; bottom: 0; width: 100%;">
        <div class="payment-block">
            <div class="swedbank-logo">
                <span style="color: #f97316;">●</span> Swedbank
            </div>

            <div class="payment-detail">
                <div class="payment-label">Receiver</div>
                <div class="payment-value">MIHAILS HOROĻSKIS</div>
            </div>

            <div class="payment-detail">
                <div class="payment-label">IBAN</div>
                <div class="payment-value payment-iban">LV04 HABA 0551 0592 0525 3</div>
            </div>

            <div class="payment-detail">
                <div class="payment-label">Payment Details / Mērķis</div>
                <div class="payment-value"
                    style="font-family: monospace; background: white; border: 1px solid #e5e7eb; display: inline-block; padding: 4px 10px; border-radius: 4px;">
                    Apmaksājums rēķinam: <?php echo e($invoice->public_id); ?>

                </div>
            </div>
        </div>

        <div class="footer clearfix">
            <div class="footer-left" style="float: left;">
                Rēķins sagatavots elektroniski un derīgs bez paraksta.
            </div>
            <div class="footer-right" style="float: right;">
                HOROLSKIS DEVELOPER
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/invoices/pdf.blade.php ENDPATH**/ ?>