<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Stats Grid -->
            <dl class="grid grid-cols-1 gap-5 sm:grid-cols-4">
                <?php if(!Auth::user()->isClient()): ?>
                    <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
                        <dt class="truncate text-sm font-medium text-gray-500">Active Clients</dt>
                        <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($stats['clients']); ?></dd>
                    </div>
                <?php endif; ?>
                <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
                    <dt class="truncate text-sm font-medium text-gray-500">Live Projects</dt>
                    <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($stats['projects']); ?></dd>
                </div>
                <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
                    <dt class="truncate text-sm font-medium text-gray-500">Unpaid Invoices</dt>
                    <dd class="mt-1 text-3xl font-semibold tracking-tight text-red-600"><?php echo e($stats['unpaid_invoices']); ?>

                    </dd>
                    <p class="text-xs text-red-500">€<?php echo e(number_format($stats['unpaid_amount'], 2)); ?> outstanding</p>
                </div>
                <?php if(!Auth::user()->isClient()): ?>
                    <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
                        <dt class="truncate text-sm font-medium text-gray-500">Active Timer</dt>
                        <?php if($stats['active_timer']): ?>
                            <dd class="mt-1 text-lg font-semibold tracking-tight text-indigo-600 truncate">
                                <?php echo e($stats['active_timer']->task->title ?? 'Task'); ?>

                            </dd>
                            <p class="text-xs text-gray-500"><?php echo e($stats['active_timer']->task->project->name ?? ''); ?></p>
                        <?php else: ?>
                            <dd class="mt-1 text-lg font-medium tracking-tight text-gray-400">Idle</dd>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </dl>

            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <!-- Recent Projects -->
                <div class="bg-white shadow sm:rounded-lg">
                    <div class="px-4 py-5 sm:px-6 border-b border-gray-200">
                        <h3 class="text-base font-semibold leading-6 text-gray-900">Recent Projects</h3>
                    </div>
                    <ul role="list" class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $recent_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="px-4 py-4 sm:px-6 hover:bg-gray-50">
                                <a href="<?php echo e(route('projects.show', $project)); ?>" class="block">
                                    <div class="flex items-center justify-between">
                                        <p class="truncate text-sm font-medium text-indigo-600"><?php echo e($project->name); ?></p>
                                        <div class="flex flex-shrink-0">
                                            <p
                                                class="inline-flex rounded-full bg-green-100 px-2 text-xs font-semibold leading-5 text-green-800">
                                                <?php echo e(ucfirst($project->status)); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <div class="mt-2 sm:flex sm:justify-between">
                                        <div class="sm:flex">
                                            <p class="flex items-center text-sm text-gray-500">
                                                <?php echo e($project->client->name); ?>

                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="px-4 py-4 text-sm text-gray-500">No projects yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Recent Invoices -->
                <div class="bg-white shadow sm:rounded-lg">
                    <div class="px-4 py-5 sm:px-6 border-b border-gray-200">
                        <h3 class="text-base font-semibold leading-6 text-gray-900">Recent Invoices</h3>
                    </div>
                    <ul role="list" class="divide-y divide-gray-100">
                        <?php $__empty_1 = true; $__currentLoopData = $recent_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="px-4 py-4 sm:px-6 hover:bg-gray-50">
                                <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="block">
                                    <div class="flex items-center justify-between">
                                        <p class="truncate text-sm font-medium text-indigo-600">
                                            #<?php echo e(str_pad($invoice->id, 5, '0', STR_PAD_LEFT)); ?></p>
                                        <p class="text-sm text-gray-500">€<?php echo e(number_format($invoice->amount, 2)); ?></p>
                                    </div>
                                    <div class="mt-2 flex justify-between">
                                        <p class="text-sm text-gray-500"><?php echo e($invoice->client->name); ?></p>
                                        <p class="text-xs text-gray-400"><?php echo e($invoice->created_at->format('M d')); ?></p>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="px-4 py-4 text-sm text-gray-500">No invoices yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/dashboard.blade.php ENDPATH**/ ?>