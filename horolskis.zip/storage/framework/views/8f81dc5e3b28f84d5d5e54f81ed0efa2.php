<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Telegram Inbox')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    
                    <?php if($messages->isEmpty()): ?>
                        <div class="text-center py-10">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">No messages yet</h3>
                            <p class="mt-1 text-sm text-gray-500">Messages sent to your bot will appear here.</p>
                            <p class="mt-4 text-xs text-gray-400">Webhook URL: <?php echo e(route('telegram.index')); ?>/webhook</p>
                        </div>
                    <?php else: ?>
                        <ul role="list" class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex gap-x-4 py-5 hover:bg-gray-50 px-4 rounded-lg transition">
                                    <div class="flex-none">
                                        <span class="inline-flex items-center justify-center h-10 w-10 rounded-full bg-indigo-500 text-white font-semibold">
                                            <?php echo e(strtoupper(substr($message->sender_name ?? 'U', 0, 1))); ?>

                                        </span>
                                    </div>
                                    <div class="min-w-0 flex-auto">
                                        <p class="text-sm font-semibold leading-6 text-gray-900">
                                            <?php echo e($message->sender_name ?? 'Unknown User'); ?> 
                                            <span class="font-normal text-gray-500 text-xs ml-2">ID: <?php echo e($message->chat_id); ?></span>
                                        </p>
                                        <p class="mt-1 text-sm leading-5 text-gray-600 break-words"><?php echo e($message->message_text); ?></p>
                                    </div>
                                    <div class="hidden sm:flex sm:flex-col sm:items-end">
                                        <p class="text-xs leading-5 text-gray-500"><?php echo e($message->created_at->diffForHumans()); ?></p>
                                        <p class="text-xs leading-5 text-gray-400"><?php echo e($message->created_at->format('M d, H:i')); ?></p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="mt-4">
                            <?php echo e($messages->links()); ?>

                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/mihailssegins/Desktop/horolskis/devops-helper/resources/views/telegram/index.blade.php ENDPATH**/ ?>